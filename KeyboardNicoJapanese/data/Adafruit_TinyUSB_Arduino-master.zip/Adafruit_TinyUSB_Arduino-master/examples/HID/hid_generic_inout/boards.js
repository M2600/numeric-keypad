module.exports = {
	"Feather_nRF52840":[0X239A,0X8029],
	"Metro_nRF52840":[0X239A,0X803F],
	"Circuit_Playground_Express":[0X239A,0X8018],
}